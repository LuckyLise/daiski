<?php
include '../pdo_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];

    $sql = "INSERT INTO Courses (name, description) VALUES (:name, :description)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['name' => $name, 'description' => $description]);

    header("Location: courses.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>新增課程</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4">新增課程</h1>
    <form method="POST">
        <div class="mb-3">
            <label>課程名稱</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>課程描述</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-success">新增</button>
    </form>
</div>
</body>
</html>
