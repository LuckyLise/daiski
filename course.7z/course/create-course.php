<?php 
require_once("../pdo_connect.php");


?>

<!doctype html>
<html lang="en">
    <head>
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <?php include("./css.php") ?>
    </head>

    <body>

    <div class="container">
        <div class="py-2">
            <h2 class="fw-bold">所有課程</h2>
            <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-2">
                <label for="" class="form-label">名稱</label>
                <input type="text" class="form-control" name="name">

            </div>
            <div class="mb-2">
                <label for="" class="form-label">選取檔案</label>
                <input type="file" class="form-control" name="image" accept=".jpg, .jpeg, .png">

            </div>
            <button class="btn btn-primary" type="submit">送出</button>
        </form>
        </div>
    </div>


        <?php include("./js.php")?>
    </body>
</html>
