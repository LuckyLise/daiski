<?php
include '../pdo_connect.php';

// **處理新增課程（表單提交）**
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_course'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];

    // 插入新課程
    $stmt = $db_host->prepare("INSERT INTO course (name, description) VALUES (:name, :description)");
    $stmt->execute(['name' => $name, 'description' => $description]);

    // 重新整理頁面，確保資料被更新
    header("Location: courses.php");
    exit();
}

// **獲取地點列表**
$locations_stmt = $db_host->query("SELECT id, name FROM locations");
$locations = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);

// **處理篩選條件**
$filter = "";
$bindParams = [];

if (isset($_GET['type']) && $_GET['type'] !== 'all') {
    $filter .= " AND cv.type = :type";
    $bindParams[':type'] = $_GET['type'];
}
if (isset($_GET['difficulty']) && !empty($_GET['difficulty'])) {
    $filter .= " AND cv.difficulty = :difficulty";
    $bindParams[':difficulty'] = $_GET['difficulty'];
}
if (isset($_GET['location_id']) && !empty($_GET['location_id'])) {
    $filter .= " AND cv.location_id = :location_id";
    $bindParams[':location_id'] = $_GET['location_id'];
}

// **查詢課程**
$sql = "SELECT c.name, c.description, cv.type, cv.difficulty, cv.duration, cv.price, l.name as location_name 
        FROM coursevariants AS cv
        JOIN course AS c ON cv.course_id = c.id
        JOIN locations AS l ON cv.location_id = l.id
        WHERE 1=1 $filter";

$stmt = $db_host->prepare($sql);
foreach ($bindParams as $key => $value) {
    $stmt->bindParam($key, $value);
}
$stmt->execute();
$courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>課程管理</title>
    <?php include("./css.php") ?>
</head>
<body>
<div class="container">
    <h1 class="mt-4">課程列表</h1>

    <!-- 🔹 篩選表單 -->
    <form method="GET" class="row g-3">
        <div class="col-md-3">
            <label>類型</label>
            <select name="type" class="form-control">
                <option value="all" <?= isset($_GET['type']) && $_GET['type'] === 'all' ? 'selected' : '' ?>>全部</option>
                <option value="ski" <?= isset($_GET['type']) && $_GET['type'] === 'ski' ? 'selected' : '' ?>>雙板</option>
                <option value="snowboard" <?= isset($_GET['type']) && $_GET['type'] === 'snowboard' ? 'selected' : '' ?>>單板</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>難度</label>
            <select name="difficulty" class="form-control">
                <option value="">全部</option>
                <option value="beginner" <?= isset($_GET['difficulty']) && $_GET['difficulty'] === 'beginner' ? 'selected' : '' ?>>初級</option>
                <option value="intermediate" <?= isset($_GET['difficulty']) && $_GET['difficulty'] === 'intermediate' ? 'selected' : '' ?>>中級</option>
                <option value="advanced" <?= isset($_GET['difficulty']) && $_GET['difficulty'] === 'advanced' ? 'selected' : '' ?>>高級</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>地點</label>
            <select name="location_id" class="form-control">
                <option value="">全部</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?= $location['id'] ?>" <?= isset($_GET['location_id']) && $_GET['location_id'] == $location['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($location['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary me-2">篩選</button>
            <a href="create-course1.php" class="btn btn-secondary">重設</a>
        </div>
    </form>

    <!-- 🔹 新增課程表單 -->
    <h2 class="mt-4">新增課程</h2>
    <form method="POST">
        <input type="hidden" name="add_course" value="1">
        <div class="row g-3">
            <div class="col-md-4">
                <label>課程名稱</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label>課程描述</label>
                <input type="text" name="description" class="form-control" required>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-success">新增</button>
            </div>
        </div>
    </form>

    <!-- 🔹 課程列表 -->
    <table class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>名稱</th>
                <th>描述</th>
                <th>類型</th>
                <th>難度</th>
                <th>時長</th>
                <th>價格</th>
                <th>地點</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($courses as $course): ?>
                <tr>
                    <td><?= htmlspecialchars($course['name']) ?></td>
                    <td><?= htmlspecialchars($course['description']) ?></td>
                    <td><?= htmlspecialchars($course['type']) ?></td>
                    <td><?= htmlspecialchars($course['difficulty']) ?></td>
                    <td><?= htmlspecialchars($course['duration']) ?> 小時</td>
                    <td>$<?= htmlspecialchars($course['price']) ?></td>
                    <td><?= htmlspecialchars($course['location_name']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include("./js.php")?>
</body>
</html>
